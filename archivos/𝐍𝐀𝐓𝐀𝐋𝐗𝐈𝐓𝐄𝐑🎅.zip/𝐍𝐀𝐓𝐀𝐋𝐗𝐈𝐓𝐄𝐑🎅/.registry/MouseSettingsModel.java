public class MouseSettingsModel {
    private int mouseSensitivity = 9000; // Sensibilidad predeterminada
    private String smoothMouseXCurve = "0,0,1,1";
    private String smoothMouseYCurve = "0,0,1,1";
    private String smoothMouseXCurve2 = "1,1,2,2";
    private String smoothMouseYCurve2 = "1,1,2,2";

    // Getters y Setters
    public int getMouseSensitivity() {
        return mouseSensitivity;
    }

    public void setMouseSensitivity(int mouseSensitivity) {
        this.mouseSensitivity = mouseSensitivity;
    }

    public String getSmoothMouseXCurve() {
        return smoothMouseXCurve;
    }

    public void setSmoothMouseXCurve(String smoothMouseXCurve) {
        this.smoothMouseXCurve = smoothMouseXCurve;
    }

    public String getSmoothMouseYCurve() {
        return smoothMouseYCurve;
    }

    public void setSmoothMouseYCurve(String smoothMouseYCurve) {
        this.smoothMouseYCurve = smoothMouseYCurve;
    }

    public String getSmoothMouseXCurve2() {
        return smoothMouseXCurve2;
    }

    public void setSmoothMouseXCurve2(String smoothMouseXCurve2) {
        this.smoothMouseXCurve2 = smoothMouseXCurve2;
    }

    public String getSmoothMouseYCurve2() {
        return smoothMouseYCurve2;
    }

    public void setSmoothMouseYCurve2(String smoothMouseYCurve2) {
        this.smoothMouseYCurve2 = smoothMouseYCurve2;
    }
}