import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.File;

public class ConfigXMLLoader {
    public static ConfigXMLModel loadConfig(String filePath) throws JAXBException {
        JAXBContext context = JAXBContext.newInstance(ConfigXMLModel.class);
        Unmarshaller unmarshaller = context.createUnmarshaller();
        return (ConfigXMLModel) unmarshaller.unmarshal(new File(filePath));
    }

    public static void main(String[] args) {
        try {
            ConfigXMLModel config = loadConfig("path/to/config.xml");

            // Acceso a configuraciones actualizadas
            System.out.println("Sensitivity X: " + config.getSensitivity().getX());
            System.out.println("Sensitivity Y: " + config.getSensitivity().getY());
            System.out.println("AimFOV: " + config.getAimfov());
        } catch (JAXBException e) {
            e.printStackTrace();
        }
    }
}

// Modelo para el archivo XML
class ConfigXMLModel {
    private Sensitivity sensitivity;
    private int aimfov;

    // Getters y Setters

    public static class Sensitivity {
        private int x = 9000;
        private int y = 9000;

        // Getters y Setters
    }
}