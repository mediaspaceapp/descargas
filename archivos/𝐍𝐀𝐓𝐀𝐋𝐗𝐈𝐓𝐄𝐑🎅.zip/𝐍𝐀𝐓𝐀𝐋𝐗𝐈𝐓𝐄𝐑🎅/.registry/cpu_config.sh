#!/system/bin/sh
# Configuración de overclocking y governor de CPU

# Establecer el governor de rendimiento
echo "performance" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor

# Establecer la frecuencia máxima de la CPU (Ejemplo: 2GHz)
echo 2000000 > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq