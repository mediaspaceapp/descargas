let horizontalSensitivity = 9000;
let verticalSensitivity = 9000;

let horizontalInput = UnityEngine.Input.GetAxis("Horizontal") * horizontalSensitivity;
let verticalInput = UnityEngine.Input.GetAxis("Vertical") * verticalSensitivity;

transform.Translate(horizontalInput * UnityEngine.Time.deltaTime, 0, verticalInput * UnityEngine.Time.deltaTime);

return 0;
