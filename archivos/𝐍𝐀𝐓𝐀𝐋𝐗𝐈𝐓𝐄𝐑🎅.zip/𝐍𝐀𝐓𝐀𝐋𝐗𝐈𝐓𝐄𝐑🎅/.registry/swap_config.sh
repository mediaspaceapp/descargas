#!/system/bin/sh
# Crear y activar archivo swap de 512MB

dd if=/dev/zero of=/data/swapfile bs=1024 count=524288
mkswap /data/swapfile
swapon /data/swapfile