#!/system/bin/sh
# Configuración de la frecuencia de actualización de la pantalla

# Establecer la frecuencia de actualización a 90Hz (si el dispositivo lo soporta)
echo 90 > /sys/class/drm/card0/device/drm_dp_aux0/refresh_rate