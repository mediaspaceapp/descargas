import java.util.List;

public class GameConfigModel {
    private Script script;
    private List<Configuration> configurations;
    private Features features;
    private SystemSettings system;
    private Feature optimization;
    private Type type;

    // Getters y Setters

    public static class Script {
        private String name;
        private String value;

        // Getters y Setters
        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }

    public static class Configuration {
        private String name;
        private String value;

        // Getters y Setters
        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }

    public static class Features {
        private List<Feature> featureList;

        // Getters y Setters
        public List<Feature> getFeatureList() {
            return featureList;
        }

        public void setFeatureList(List<Feature> featureList) {
            this.featureList = featureList;
        }
    }

    public static class Feature {
        private String name;
        private String target;
        private String description;
        private List<Block> blocks;
        private List<Configuration> configurations;

        // Getters y Setters
        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getTarget() {
            return target;
        }

        public void setTarget(String target) {
            this.target = target;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public List<Block> getBlocks() {
            return blocks;
        }

        public void setBlocks(List<Block> blocks) {
            this.blocks = blocks;
        }

        public List<Configuration> getConfigurations() {
            return configurations;
        }

        public void setConfigurations(List<Configuration> configurations) {
            this.configurations = configurations;
        }
    }

    public static class Block {
        private String name;
        private String configSections;

        // Getters y Setters
        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getConfigSections() {
            return configSections;
        }

        public void setConfigSections(String configSections) {
            this.configSections = configSections;
        }
    }

    public static class SystemSettings {
        private List<Configuration> configurations;

        // Getters y Setters
        public List<Configuration> getConfigurations() {
            return configurations;
        }

        public void setConfigurations(List<Configuration> configurations) {
            this.configurations = configurations;
        }
    }

    public static class Type {
        private String name;

        // Getters y Setters
        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }
}