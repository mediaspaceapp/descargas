const sensitivities = new Map();

sensitivities.set("ScreenX", 9000);
sensitivities.set("ScreenY", 9000);
sensitivities.set("Joystick", 9000);
sensitivities.set("Aim", 9000);
sensitivities.set("Shoot", 9000);

console.log("<Sensitivities>");
for (const [name, value] of sensitivities) {
  console.log(`  <Sensitivity name="" value="" />`);
}
console.log("</Sensitivities>");
