import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.File;

public class GameConfigXMLLoader {
    public static GameConfigModel loadConfig(String filePath) throws JAXBException {
        JAXBContext context = JAXBContext.newInstance(GameConfigModel.class);
        Unmarshaller unmarshaller = context.createUnmarshaller();
        return (GameConfigModel) unmarshaller.unmarshal(new File(filePath));
    }

    public static void main(String[] args) {
        try {
            GameConfigModel config = loadConfig("path/to/gameConfiguration.xml");

            // Mostrar información del script
            System.out.println("Script Name: " + config.getScript().getName());
            System.out.println("Script Value: " + config.getScript().getValue());
        } catch (JAXBException e) {
            e.printStackTrace();
        }
    }
}