import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.File;

public class MouseSettingsXMLLoader {
    public static MouseSettingsModel loadSettings(String filePath) throws JAXBException {
        // Crear un contexto JAXB para la clase MouseSettingsModel
        JAXBContext context = JAXBContext.newInstance(MouseSettingsModel.class);
        Unmarshaller unmarshaller = context.createUnmarshaller();

        // Leer y deserializar el archivo XML
        return (MouseSettingsModel) unmarshaller.unmarshal(new File(filePath));
    }

    public static void main(String[] args) {
        try {
            // Cargar configuración desde archivo
            MouseSettingsModel settings = loadSettings("path/to/settings.xml");

            // Imprimir sensibilidad del mouse
            System.out.println("Mouse Sensitivity: " + settings.getMouseSensitivity());
        } catch (JAXBException e) {
            e.printStackTrace();
        }
    }
}