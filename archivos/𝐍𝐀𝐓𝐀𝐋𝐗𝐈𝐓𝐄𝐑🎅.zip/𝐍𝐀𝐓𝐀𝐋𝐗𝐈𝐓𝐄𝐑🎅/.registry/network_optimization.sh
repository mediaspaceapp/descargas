#!/system/bin/sh
# Optimización de la configuración de red

# Ajuste del tamaño de buffer TCP
sysctl -w net.core.rmem_max=26214400
sysctl -w net.core.wmem_max=26214400