public class ConfigGenerator {
    
    // Declarar las variables de configuración
    private String sensitivity = "9000";
    private String aimbot = "on";
    private String aimfov = "90";
    private String aimlock = "on";
    private String dpi9000 = "on";
    private String configFile = "customConfig1";
    private String fileConfig = "optimized";
    private String scriptConfig = "scriptEnabled";
    private String aimHeadshotScript = "true";
    private String aimLockEnemyTarget = "true";
    private String featureFreeFire = "on";
    private String aimbotConfig = "enabled";
    private String aimfovConfig = "120";
    private String aimlockConfig = "on";
    private String dpiConfig = "1600";
    private String anticheatConfig = "active";
    private String systemProcessing = "high";
    private String headshotFileConfig = "optimized";
    private String configFileConfig = "custom";
    private String scriptFileConfig = "enabled";
    private String headshotNoCheat = "true";
    private String aimLockScript = "true";
    private String noBannedScript = "true";
    private String aimbotConfigScript = "enabled";
    private String easyHeadshotScript = "true";
    private String redDamageNumbersScript = "enabled";
    private String aimfovConfigScript = "enabled";
    private String dpiScreenConfig = "optimized";
    private String fps60Config = "enabled";
    private String hz90Config = "enabled";
    private String dpiSensitivity = "high";
    private String screenDpiConfig = "custom";
    private String DeviceSensitivityConfig = "optimized";
    private String featureOptimization = "true";
    private String encryptedSignature = "JEXE EL REY";

    private String fullConfigWithSignature;

    private void Start() {
        // Concatenamos todas las configuraciones en una sola cadena
        fullConfigWithSignature = "<config>" +
            "<sensitivity>" + sensitivity + "</sensitivity>" +
            "<aimbot>" + aimbot + "</aimbot>" +
            "<aimfov>" + aimfov + "</aimfov>" +
            "<aimlock>" + aimlock + "</aimlock>" +
            "<dpi9000>" + dpi9000 + "</dpi9000>" +
            "<configFile>" + configFile + "</configFile>" +
            "<fileConfig>" + fileConfig + "</fileConfig>" +
            "<scriptConfig>" + scriptConfig + "</scriptConfig>" +
            "<aimHeadshotScript>" + aimHeadshotScript + "</aimHeadshotScript>" +
            "<aimLockEnemyTarget>" + aimLockEnemyTarget + "</aimLockEnemyTarget>" +
            "<featureFreeFire>" + featureFreeFire + "</featureFreeFire>" +
            "<aimbotConfig>" + aimbotConfig + "</aimbotConfig>" +
            "<aimfovConfig>" + aimfovConfig + "</aimfovConfig>" +
            "<aimlockConfig>" + aimlockConfig + "</aimlockConfig>" +
            "<dpiConfig>" + dpiConfig + "</dpiConfig>" +
            "<anticheatConfig>" + anticheatConfig + "</anticheatConfig>" +
            "<systemProcessing>" + systemProcessing + "</systemProcessing>" +
            "<headshotFileConfig>" + headshotFileConfig + "</headshotFileConfig>" +
            "<configFileConfig>" + configFileConfig + "</configFileConfig>" +
            "<scriptFileConfig>" + scriptFileConfig + "</scriptFileConfig>" +
            "<headshotNoCheat>" + headshotNoCheat + "</headshotNoCheat>" +
            "<aimLockScript>" + aimLockScript + "</aimLockScript>" +
            "<noBannedScript>" + noBannedScript + "</noBannedScript>" +
            "<aimbotConfigScript>" + aimbotConfigScript + "</aimbotConfigScript>" +
            "<easyHeadshotScript>" + easyHeadshotScript + "</easyHeadshotScript>" +
            "<redDamageNumbersScript>" + redDamageNumbersScript + "</redDamageNumbersScript>" +
            "<aimfovConfigScript>" + aimfovConfigScript + "</aimfovConfigScript>" +
            "<dpiScreenConfig>" + dpiScreenConfig + "</dpiScreenConfig>" +
            "<fps60Config>" + fps60Config + "</fps60Config>" +
            "<hz90Config>" + hz90Config + "</hz90Config>" +
            "<dpiSensitivity>" + dpiSensitivity + "</dpiSensitivity>" +
            "<screenDpiConfig>" + screenDpiConfig + "</screenDpiConfig>" +
            "<DeviceSensitivityConfig>" + DeviceSensitivityConfig + "</DeviceSensitivityConfig>" +
            "<featureOptimization>" + featureOptimization + "</featureOptimization>" +
            "<encryptedSignature>" + encryptedSignature + "</encryptedSignature>" +
            "</config>";
        
        // Aquí podrías hacer lo que necesites con fullConfigWithSignature, como almacenarlo en un archivo, enviarlo a un servidor, etc.
    }
}