#include <iostream>
#include <vector>
#include <cmath>
#include <string>
#include <sstream>
#include <rapidxml.hpp>

using namespace std;

struct GameConfig {
    string directoryPath;
    string mainPath;
    string versionInfo;
};

struct AppSettings {
    double SensitivityX;
    double SensitivityY;
};

struct ScreenSettings {
    double touchSensitivity;
    double scrollSpeed;
    double tapResponse;
};

struct DeviceSettings {
    ScreenSettings screenSettings;
};

struct ConfigurationData {
    GameConfig gameConfig;
    AppSettings appSettings;
    DeviceSettings deviceSettings;
};

int main() {
    ConfigurationData configData;

    string xmlData = 
    rapidxml::xml_document<> doc;
    doc.parse<0>(const_cast<char*>(xmlData.c_str()));

    rapidxml::xml_node<>* gameConfigNode = doc.first_node("configurationData")->first_node("gameConfig");
    configData.gameConfig.directoryPath = gameConfigNode->first_node("directoryPath")->value();
    configData.gameConfig.mainPath = gameConfigNode->first_node("mainPath")->value();
    configData.gameConfig.versionInfo = gameConfigNode->first_node("versionInfo")->value();

    rapidxml::xml_node<>* appSettingsNode = doc.first_node("configurationData")->first_node("configuration")->first_node("appSettings");
    configData.appSettings.SensitivityX = stod(appSettingsNode->first_node("add")->first_attribute("value")->value());
    configData.appSettings.SensitivityY = stod(appSettingsNode->first_node("add")->next_sibling("add")->first_attribute("value")->value());

    rapidxml::xml_node<>* screenSettingsNode = doc.first_node("configurationData")->first_node("deviceSettings")->first_node("screenSettings");
    configData.deviceSettings.screenSettings.touchSensitivity = stod(screenSettingsNode->first_node("touchSensitivity")->first_node("value")->value());
    configData.deviceSettings.screenSettings.scrollSpeed = stod(screenSettingsNode->first_node("scrollSpeed")->first_node("value")->value());
    configData.deviceSettings.screenSettings.tapResponse = stod(screenSettingsNode->first_node("tapResponse")->first_node("value")->value());

    cout << "Directory Path: " << configData.gameConfig.directoryPath << endl;
    cout << "Main Path: " << configData.gameConfig.mainPath << endl;
    cout << "Version Info: " << configData.gameConfig.versionInfo << endl;
    cout << "SensitivityX: " << configData.appSettings.SensitivityX << endl;
    cout << "SensitivityY: " << configData.appSettings.SensitivityY << endl;
    cout << "Touch Sensitivity: " << configData.deviceSettings.screenSettings.touchSensitivity << endl;
    cout << "Scroll Speed: " << configData.deviceSettings.screenSettings.scrollSpeed << endl;
    cout << "Tap Response: " << configData.deviceSettings.screenSettings.tapResponse << endl;

    return 0;
}