class ScriptableObject {
  constructor() {
    this.monoBehaviour = new MonoBehaviour();
  }
}

class MonoBehaviour {
  constructor() {
    this.ClassName = "";
    this.references = new References();
    this.fields = new Fields();
    this.methods = new Methods();
  }
}

class References {
  constructor() {
    this.reference = new Reference();
  }
}

class Reference {
  constructor() {
    this.Name = "";
  }
}

class Fields {
  constructor() {
    this.field = new Field();
  }
}

class Field {
  constructor() {
    this.Name = "";
    this.Type = "";
    this.Value = 0.0;
  }
}

class Methods {
  constructor() {
    this.method = new Method();
  }
}

class Method {
  constructor() {
    this.Name = "";
    this.ReturnType = "";
    this.statements = new Statements();
  }
}

class Statements {
  constructor() {
    this.statement = new Statement();
  }
}

class Statement {
  constructor() {
    this.declarationStatement = new DeclarationStatement();
    this.expression = new Expression();
  }
}

class DeclarationStatement {
  constructor() {
    this.Type = "";
    this.Name = "";
    this.initializer = new Initializer();
  }
}

class Initializer {
  constructor() {
    this.expression = new Expression();
  }
}

class Expression {
  constructor() {
    this.callExpression = new CallExpression();
    this.getProperty = new GetProperty();
    this.NumberLiteral = "";
    this.unaryOperator = new UnaryOperator();
  }
}

class CallExpression {
  constructor() {
    this.Target = "";
    this.MethodName = "";
    this.arguments = new Arguments();
  }
}

class Arguments {
  constructor() {
    this.argument = new Argument();
  }
}

class Argument {
  constructor() {
    this.StringLiteral = "";
  }
}

class GetProperty {
  constructor() {
    this.Target = "";
    this.PropertyName = "";
  }
}

const scriptableObject = new ScriptableObject();
scriptableObject.monoBehaviour.ClassName = "ScreenSensitivity";
scriptableObject.monoBehaviour.references.reference.Name = "UnityEngine";
scriptableObject.monoBehaviour.fields.field.Name = "sensitivity";
scriptableObject.monoBehaviour.fields.field.Type = "float";
scriptableObject.monoBehaviour.fields.field.Value = 9000;
scriptableObject.monoBehaviour.methods.method.Name = "Update";
scriptableObject.monoBehaviour.methods.method.ReturnType = "void";
scriptableObject.monoBehaviour.methods.method.statements.statement.declarationStatement.Type = "Vector2";
scriptableObject.monoBehaviour.methods.method.statements.statement.declarationStatement.Name = "input";
scriptableObject.monoBehaviour.methods.method.statements.statement.declarationStatement.initializer.expression.binaryOperator.leftOperand.binaryOperator.leftOperand.callExpression.Target = "UnityEngine.Input";
scriptableObject.monoBehaviour.methods.method.statements.statement.declarationStatement.initializer.expression.binaryOperator.leftOperand.binaryOperator.leftOperand.callExpression.MethodName = "GetAxis";
scriptableObject.monoBehaviour.methods.method.statements.statement.declarationStatement.initializer.expression.binaryOperator.leftOperand.binaryOperator.leftOperand.callExpression.arguments.argument.StringLiteral = "Mouse X";
scriptableObject.monoBehaviour.methods.method.statements.statement.declarationStatement.initializer.expression.binaryOperator.leftOperand.binaryOperator.rightOperand.callExpression.Target = "UnityEngine.Input";
scriptableObject.monoBehaviour.methods.method.statements.statement.declarationStatement.initializer.expression.binaryOperator.leftOperand.binaryOperator.rightOperand.callExpression.MethodName = "GetAxis";
scriptableObject.monoBehaviour.methods.method.statements.statement.declarationStatement.initializer.expression.binaryOperator.leftOperand.binaryOperator.rightOperand.callExpression.arguments.argument.StringLiteral = "Mouse Y";
scriptableObject.monoBehaviour.methods.method.statements.statement.declarationStatement.initializer.expression.binaryOperator.rightOperand.Variable = "sensitivity";
scriptableObject.monoBehaviour.methods.method.statements.statement.expression.callExpression.Target = "transform";
scriptableObject.monoBehaviour.methods.method.statements.statement.expression.callExpression.MethodName = "Rotate";
scriptableObject.monoBehaviour.methods.method.statements.statement.expression.callExpression.arguments.argument.unaryOperator.Operator = "-";
scriptableObject.monoBehaviour.methods.method.statements.statement.expression.callExpression.arguments.argument.unaryOperator.operand.getProperty.Target = "input";
scriptableObject.monoBehaviour.methods.method.statements.statement.expression.callExpression.arguments.argument.unaryOperator.operand.getProperty.PropertyName = "y";
scriptableObject.monoBehaviour.methods.method.statements.statement.expression.callExpression.arguments.argument.getProperty.Target = "input";
scriptableObject.monoBehaviour.methods.method.statements.statement.expression.callExpression.arguments.argument.getProperty.PropertyName = "x";
scriptableObject.monoBehaviour.methods.method.statements.statement.expression.callExpression.arguments.argument.NumberLiteral = "0f";
