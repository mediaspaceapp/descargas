// JavaScript code for aimbot functionality

// Target elements
var player = document.getElementById('player');
var head = document.getElementById('head');
var enemy = document.getElementById('enemy');

// Configuration variables
var sensitivityWeapon = 9000;
var aimfov = 1.0;
var aimlockEnabled = true;

// Function to calculate the aim target
function calculateAimTarget(targetElement) {
    return {
        x: targetElement.x,
        y: targetElement.y
    };
}

// Function to aim at the target
function aimAtTarget(target, sensitivity) {
    var dx = target.x - player.x;
    var dy = target.y - player.y;
    var angle = Math.atan2(dy, dx) * (180 / Math.PI); // Convert to degrees
    var adjustedAngle = angle * (sensitivity / 100); // Adjust angle by sensitivity
    player.rotation = adjustedAngle; // Update player rotation
}

// Aimbot function
function aimbot() {
    var target;
    
    // Determine which target to use
    if (document.getElementById('head')) {
        target = calculateAimTarget(head);
    } else if (document.getElementById('enemy')) {
        target = calculateAimTarget(enemy);
    }

    // Aim at the target if available
    if (target) {
        aimAtTarget(target, sensitivityWeapon);
    }

    requestAnimationFrame(aimbot); // Continue aiming
}

// Enable aim headshot functionality
function enableAimHeadshot() {
    // Placeholder for enabling aim headshot logic
}

// Enable aim lock functionality
function enableAimlock() {
    aimlockEnabled = true;
}

// Disable aim lock functionality
function disableAimlock() {
    aimlockEnabled = false;
}

// Start the aimbot
aimbot();