#!/system/bin/sh
# Configuración de DPI

# Cambiar el DPI a 9000
wm density 9000