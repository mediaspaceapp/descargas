using System;
using System.IO;
using System.Xml.Linq;
using System.Linq;

class Program
{
    // Estructura de configuración
    static double noRecoil = 0.90;
    static double aimFov = 0.90;
    static double aimLock = 0.90;
    static double aimBot = 0.90;
    static double aimAssist = 0.90;
    static int sensitivity = 9000;
    static bool isAiming = false;

    // Función para alternar características
    static void ToggleFeature(string featureFreeFire, bool isEnabled)
    {
        if (featureFreeFire == "aimBot")
        {
            aimBot = isEnabled && isAiming ? 1.0 : 0.0;
        }
        else if (featureFreeFire == "aimFov")
        {
            isAiming = isEnabled;
        }
        // Puedes agregar más características aquí
    }

    static void Main()
    {
        // Ejemplo: Activar el aimbot y desactivar aimFov
        ToggleFeature("aimBot", true);
        ToggleFeature("aimFov", false);

        // Convertir la configuración a XML
        var configXML = new XElement("DAPT",
            new XAttribute("type", "script"),
            new XElement("configuration",
                new XElement("com.dts.freefireth~[sensitivity]",
                    new XElement("noRecoil", noRecoil),
                    new XElement("aimFov", aimFov),
                    new XElement("aimLock", aimLock),
                    new XElement("aimBot", aimBot),
                    new XElement("aimAssist", aimAssist),
                    new XElement("sensitivity", sensitivity)
                )
            )
        );

        // Guardar la configuración en un archivo XML
        var configPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "config.xml");
        configXML.Save(configPath);

        Console.WriteLine("Configuration saved successfully in config.xml");
    }
}