let sightSensitivity = 9000;

let inputHorizontal = UnityEngine.Input.GetAxis("Mouse X") * sightSensitivity;
let inputVertical = UnityEngine.Input.GetAxis("Mouse Y") * sightSensitivity;

transform.Rotate(-inputVertical, inputHorizontal, 0);
