#include <iostream>
#include <windows.h>

// Definir los tipos de las funciones que cargaremos desde la DLL
typedef void (*ToggleFeatureFunc)(const char* feature, bool enabled);
typedef void (*SaveConfigurationFunc)();

int main() {
    // Cargar la DLL
    HINSTANCE hDLL = LoadLibrary("YourDLL.dll");

    if (hDLL == NULL) {
        std::cerr << "Error loading DLL." << std::endl;
        return 1; // Terminar si no se pudo cargar la DLL
    }

    // Obtener las direcciones de las funciones exportadas
    ToggleFeatureFunc toggleFeature = (ToggleFeatureFunc)GetProcAddress(hDLL, "toggleFeature");
    SaveConfigurationFunc saveConfiguration = (SaveConfigurationFunc)GetProcAddress(hDLL, "saveConfiguration");

    if (toggleFeature == NULL || saveConfiguration == NULL) {
        std::cerr << "Error getting function addresses." << std::endl;
        FreeLibrary(hDLL); // Liberar la DLL en caso de error
        return 1;
    }

    // Ejemplo: Activar el Aimbot y desactivar el AimFov
    toggleFeature("aimBot", true);  // Activa Aimbot
    toggleFeature("aimFov", false); // Desactiva AimFov

    // Guardar la configuración en un archivo XML
    saveConfiguration();

    // Liberar la DLL cuando ya no se necesita
    FreeLibrary(hDLL);

    return 0;
}
