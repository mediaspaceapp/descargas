public class MouseSettingsModel {
    // Configuraciones generales del mouse
    private int activeWindowTracking = 1;
    private String beep = "on";
    private int doubleClickHeight = 5;
    private int doubleClickSpeed = 500;
    private int doubleClickWidth = 5;
    private String extendedSounds = "enabled";
    private int mouseHoverHeight = 10;
    private int mouseHoverTime = 300;
    private int mouseHoverWidth = 10;
    private int mouseSensitivity = 9000; // Sensibilidad predeterminada
    private int mouseSpeed = 10;
    private int mouseThreshold1 = 6;
    private int mouseTrails = 0;

    // Curvas del mouse
    private String smoothMouseXCurve = "0, 0, 0, 0";
    private String smoothMouseYCurve = "0, 0, 0, 0";
    private String smoothMouseXCurve2 = "1, 1, 1, 1";
    private String smoothMouseYCurve2 = "1, 1, 1, 1";

    // Configuraciones adicionales
    private int snapToDefaultButton = 0;
    private int swapMouseButtons = 0;
    private String beep2 = "off";
    private String doubleClickHeight2 = "6";
    private String doubleClickSpeed2 = "400";
    private String doubleClickWidth2 = "6";
    private String extendedSounds2 = "disabled";
    private int mouseSensitivity2 = 9000; // Sensibilidad alternativa predeterminada
    private int mouseSpeed2 = 12;
    private int mouseThreshold12 = 7;
    private int mouseThreshold22 = 7;

    // Getters y Setters
    public int getMouseSensitivity() {
        return mouseSensitivity;
    }

    public void setMouseSensitivity(int mouseSensitivity) {
        this.mouseSensitivity = mouseSensitivity;
    }

    public int getMouseSpeed() {
        return mouseSpeed;
    }

    public void setMouseSpeed(int mouseSpeed) {
        this.mouseSpeed = mouseSpeed;
    }
}