import com.google.gson.Gson;

public class Main {
    public static void main(String[] args) {
        // JSON de configuración actualizado
        String json = "{ " +
                "\"aimheadshot\": \"on\", " +
                "\"dpi.screen\": 9000, " +
                "\"aimbot.ff\": \"enabled\", " +
                "\"sensitivity.weapon\": 9000, " +
                "\"aimlock.enemy\": \"active\", " +
                "\"aimfov\": 90 " +
                "}";

        // Uso de GSON para parsear el JSON
        Gson gson = new Gson();
        Configuration config = gson.fromJson(json, Configuration.class);

        // Acceso a las configuraciones actualizadas
        System.out.println("Aim Headshot: " + config.getAimheadshot());
        System.out.println("DPI Screen: " + config.getDpiScreen());
        System.out.println("Aimlock: " + config.getAimlockEnemy());
    }
}