import java.util.Map;
import java.util.List;

public class Configuration {
    private String aimheadshot;
    private int dpiScreen;
    private String aimbotFf;
    private String aimheadshotFf;
    private int sensitivityWeapon;
    private String aimlockEnemy;
    private int aimfov;
    private Features features;
    private SystemSettings system;
    private Optimization optimization;
    private String type;

    // Getters y Setters actualizados

    public static class Features {
        private FreeFire freefire;

        // Getters y Setters
    }

    public static class FreeFire {
        private String aimbot = "enabled";
        private String aimfov90 = "on";
        private String aimlock = "active";
        private String aimrednumbers = "true";
        private String dpi9000 = "set";
        private String anticheat = "bypass";

        // Getters y Setters
    }

    public static class SystemSettings {
        private String webConfigurationScripting;
        private String processing;
        private String fileHeadshot;
        private String fileConfig;
        private String script;
        private String headshotNocheat;
        private String scriptAimlock;
        private String scriptNobanned;
        private String scriptEasyheadshot;
        private String scriptRedDamageNumbers;
        private String aimfov = "90";
        private int dpiscreen9000 = 9000;
        private String sixtyFps = "enabled";
        private String sixtyHz = "on";
        private int dpiSensitivity = 9000;

        // Getters y Setters
    }

    public static class Optimization {
        private String description = "Optimization for sensitivity and aim";
        private List<Block> blocks;

        // Getters y Setters

        public static class Block {
            private String name;
            private String configSections;

            // Getters y Setters
        }
    }
}