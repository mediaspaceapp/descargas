<?xml version="1.0" encoding="UTF-8"?>
<DAPT type="script">
    <af>af</af>
    <co>co (in the game)</co>
    <in_the_game>com.dts.freefireth</in_the_game>
    <CURSOR_VALUE_GRAVITY>
        <CURSOR_1> 2019117863 </CURSOR_1>
        <CURSOR_2>scope.m.lib</CURSOR_2>
        <CURSOR_TYPE_CROSSHAIR>Density type no recoil</CURSOR_TYPE_CROSSHAIR>
    </CURSOR_VALUE_GRAVITY>
    <CURSOR_TYPE_CROSSHAIR>
        <CROSSHAIR>value off system</CROSSHAIR>
        <redirect>from query (in the game)</redirect>
    </CURSOR_TYPE_CROSSHAIR>
    <jexe-aimbot>dapt</jexe-aimbot>
    <configuration>
        <com.dts.freefireth~[sensitivity]>
            <noRecoil>0.9</noRecoil>
            <aimFov>0.9</aimFov>
            <aimLock>0.9</aimLock>
            <aimBot>0.9</aimBot> <!-- Si isAiming es false -->
            <aimAssist>0.9</aimAssist>
            <sensitivity>9000</sensitivity>
        </com.dts.freefireth~[sensitivity]>
    </configuration>
</DAPT>a configuración a formato XML
const configXML = `
<?xml version="1.0" encoding="UTF-8"?>
<DAPT type="script">
    <af>af</af>
    <co>co (in the game)</co>
    <in_the_game>com.dts.freefireth</in_the_game>
    <CURSOR_VALUE_GRAVITY>
        <CURSOR_1> 2019117685 </CURSOR_1>
        <CURSOR_2>scope.m.lib</CURSOR_2>
        <CURSOR_TYPE_CROSSHAIR>Density type no recoil</CURSOR_TYPE_CROSSHAIR>
    </CURSOR_VALUE_GRAVITY>
    <CURSOR_TYPE_CROSSHAIR>
        <CROSSHAIR>value off system</CROSSHAIR>
        <redirect>from query (in the game)</redirect>
    </CURSOR_TYPE_CROSSHAIR>
    <jexe-aimbot>dapt</jexe-aimbot>
    <configuration>
        <com.dts.freefireth~[sensitivity]>
        ${Object.keys(configuration).map(feature => {
            if (feature === "aimBot" && !configuration.isAiming) {
                return `<${feature}>0.0</${feature}>`; // Si no se está apuntando, aimBot se establece en 0.0
            }
            return `<${feature}>${configuration[feature]}</${feature}>`;
        }).join('\n')}
        </com.dts.freefireth~[sensitivity]>
    </configuration>
</DAPT>
`;

// Guardar la configuración en un archivo XML
const configFile = FileManager.local();
const configPath = configFile.joinPath(FileManager.iCloud().documentsDirectory(), "config.xml");
configFile.writeString(configPath, configXML);

console.log("Configuración guardada correctamente en config.xml");

Script.complete();;