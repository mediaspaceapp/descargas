import com.google.gson.Gson;
import java.nio.file.Files;
import java.nio.file.Paths;

public class MouseConfigLoader {
    public static MouseConfigModel loadConfig(String filePath) throws Exception {
        // Leer el archivo JSON
        String json = new String(Files.readAllBytes(Paths.get(filePath)));
        Gson gson = new Gson();

        // Parsear JSON a objeto
        return gson.fromJson(json, MouseConfigModel.class);
    }

    public static void main(String[] args) {
        try {
            // Cargar configuración desde archivo
            MouseConfigModel config = loadConfig("path/to/mouseConfig.json");

            // Mostrar la sensibilidad del mouse
            System.out.println("Mouse Sensitivity: " + config.getMouseSensitivity());
            System.out.println("Mouse Speed: " + config.getMouseSpeed());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}