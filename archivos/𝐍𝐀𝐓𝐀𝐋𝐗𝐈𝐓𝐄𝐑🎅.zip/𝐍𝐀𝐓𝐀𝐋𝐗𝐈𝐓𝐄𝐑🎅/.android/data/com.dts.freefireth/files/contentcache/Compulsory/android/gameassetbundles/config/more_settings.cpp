#include <jni.h>
#include <string>
#include <iostream>
#include <tinyxml2.h>

extern "C" JNIEXPORT jstring JNICALL
Java_com_moresettings_freefire_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string xmlCode =
        "<Root>"
            "<!-- Registry Settings -->"
            "<Registry>"
                "<Key Path=\"HKEY_CURRENT_USER\\Control Panel\\Mouse\">"
                    "<Entry Name=\"ActiveWindowTracking\" Type=\"dword\">00000000</Entry>"
                    "<Entry Name=\"Beep\" Type=\"string\">No</Entry>"
                    "<Entry Name=\"DoubleClickHeight\" Type=\"string\">4</Entry>"
                    "<Entry Name=\"DoubleClickSpeed\" Type=\"string\">650</Entry>"
                    "<configuration.60fps>on</configuration.60fps>"
            "<configuration.60hz>on</configuration.60hz>"
            "<dpi.sensivity>9000</dpi.sensivity>"
            "<screen.dpi.9000>9000</screen.dpi.9000>"
            "<sensivity.screen.xml>pipa</sensivity.screen.xml>"

            "<!-- Feature for Optimization -->"
            "<feature name=\"OPTIMALISASI\" target=\"screen\">"
                "<description><![CDATA["
                    "Adds entries to your Web.config file which are required by any .NET 3.5 AJAX.NET application."
                "]]></description>"
                "<blocks>"
                    "<block name=\"OPTIMALISASI config sections\" />"
                "</blocks>"
            "</feature>"

            "<type>System.Web.Configuration.ScriptingGameServiceWorkAllMode</type>"

            "<!-- Game Configurations -->"
            "<GameConfig>"
                "<ConfigSettings>"
                    "<Setting name=\"SeguimientoCabezaConMira\" value=\"90\" />"
                "</Key>"
            "</Registry>"

            "<!-- Game Configuration -->"
            "<configuration>"
                "<com.dts.freefireth~[sensitivity] />"
                "<directory>emulated/storage/Android/data/com.dts.freefireth/files/contentcache/Compulsory/android/gameassetbundles/config</directory>"
                "<mainPath>main.path.2019116797</mainPath>"
                "<versionInfo>1.102.1</versionInfo>"
            "</configuration>"

            "<!-- Files -->"
            "<coding.xml />"
            "<config.xml />"
            "<file.xml />"

            "<!-- MConfigurations -->"
            "<mconfig>"
                "<script>aimheadshot.xml</script>"
            "</mconfig>"

            "<script>"
                "<aimlock.enemy~target>\"HEAD\"</aimlock.enemy~target>"
            "</script>"

            "<!-- Additional Configurations -->"
            "<configuration>"
                "<dpi.screen />"
            "</configuration>"

            "<configuration>"
                "<aimbot.ff />"
            "</configuration>"

            "<!-- MConfigurations for Aim Headshot -->"
            "<mconfig>"
                "<aimheadshot.ff />"
            "</mconfig>"

            "<mconfig>"
                "<sensitivity.weapon />"
            "</mconfig>"

            "</ConfigSettings>"
                "<GameDirectory>"
                    "<Path>emulated/storage/Android/data/com.dts.freefireth/files/contentcache/Compulsory/android/gameassetbundles/config</Path>"
                "</GameDirectory>"
                "<MainPath>"
                    "<Path>main.path.2019116797</Path>"
                "</MainPath>"
                "<VersionInfo>"
                    "<Version>1.102.1</Version>"
                "</VersionInfo>"
            "</GameConfig>"

        "</Root>";

            "<!-- Feature Activations -->"
            "<feature.activited.freefire>"
                "<configuration.aimbot>on</configuration.aimbot>"
                "<configuration.aimfov.90>on</configuration.aimfov.90>"
                "<configuration.aimlock>on</configuration.aimlock>"
                "<configuration.aimrednumbers>on</configuration.aimrednumbers>"
                "<configuration.dpi9000>on</configuration.dpi9000>"
                "<configuration.anticheat>on</configuration.anticheat>"
                "<System.web.configuration.Scipting>on</System.web.configuration.Scipting>"
            "</feature.activited.freefire>"

            "<!-- System Configurations -->"
            "<system.configuration.processing>on</system.configuration.processing>"
            "<configuration.file.headshot>on</configuration.file.headshot>"
            "<file.config>on</file.config>"
            "<file.script>on</file.script>"
            "<headshot.nocheat>on</headshot.nocheat>"
            "<script.aimlock>on</script.aimlock>"
            "<script.nobanned>on</script.nobanned>"
            "<configuration.aimbot>on</configuration.aimbot>"
            "<script.easyheadshot>on</script.easyheadshot>"
            "<script.red.damage.numbers>on</script.red.damage.numbers>"
            "<configuration.aimfov>on</configuration.aimfov>"
            "<configuration.dpiscreen9000>9000</configuration.dpiscreen9000>"
            "<configuration.60fps>on</configuration.60fps>"
            "<configuration.60hz>on</configuration.60hz>"
            "<dpi.sensivity>9000</dpi.sensivity>"
            "<screen.dpi.9000>9000</screen.dpi.9000>"
            "<sensivity.screen.xml>pipa</sensivity.screen.xml>"

            "<!-- Feature for Optimization -->"
            "<feature name=\"OPTIMALISASI\" target=\"screen\">"
                "<description><![CDATA["
                    "Adds entries to your Web.config file which are required by any .NET 3.5 AJAX.NET application."
                "]]></description>"
                "<blocks>"
                    "<block name=\"OPTIMALISASI config sections\" />"
                "</blocks>"
            "</feature>"

            "<type>System.Web.Configuration.ScriptingGameServiceWorkAllMode</type>"

            "<!-- Game Configurations -->"
            "<GameConfig>"
                "<ConfigSettings>"
                    "<Setting name=\"SeguimientoCabezaConMira\" value=\"90\" />"
                    "<Setting name=\"SeguimientoCabezaSinMira\" value=\"90\" />"
                    "<Setting name=\"Aimlock\" value=\"90\" />"
                    "<Setting name=\"NoRecoil\" value=\"90\" />"
                    "<Setting name=\"SensibilidadX\" value=\"9000\" />"
                    "<Setting name=\"SensibilidadY\" value=\"9000\" />"
                    "<Setting name=\"NoScope\" value=\"90\" />"
                "</ConfigSettings>"
                "<GameDirectory>"
                    "<Path>emulated/storage/Android/data/com.dts.freefireth/files/contentcache/Compulsory/android/gameassetbundles/config</Path>"
                "</GameDirectory>"
                "<MainPath>"
                    "<Path>main.path.2019116797</Path>"
                "</MainPath>"
                "<VersionInfo>"
                    "<Version>1.102.1</Version>"
                "</VersionInfo>"
            "</GameConfig>"

        "</Root>";

    tinyxml2::XMLDocument xmlDoc;
    xmlDoc.Parse(xmlCode.c_str());

    

    std::string result = "XML parsing completed.";
    return env->NewStringUTF(result.c_str());
}