#include <iostream>
#include <vector>
#include <cmath>
#include <string>
#include <sstream>
#include <rapidxml.hpp>

using namespace std;

struct GameConfig {
    string directoryPath;
    string mainPath;
    string versionInfo;
};

struct AppSettings {
    double SensitivityX;
    double SensitivityY;
};

struct ScreenSettings {
    double touchSensitivity;
    double scrollSpeed;
    double tapResponse;
};

struct DeviceSettings {
    ScreenSettings screenSettings;
    
};

struct ConfigurationData {
    GameConfig gameConfig;
    AppSettings appSettings;
    DeviceSettings deviceSettings;
    
};

int main() {
    ConfigurationData configData;

    
    string xmlData = "<configurationData>
  <gameConfig>
    <directoryPath>emulated/storage/Android/data/com.dts.freefireth/files/contentcache/Compulsory/android/gameassetbundles/config</directoryPath>
    <mainPath>main.path.2019116797</mainPath>
    <versionInfo>1.102.1</versionInfo>
  </gameConfig>

  <configuration>
    <appSettings>
      <add key="SensitivityX" value="9000.0" />
      <add key="SensitivityY" value="9000.0" />
    </appSettings>

    <gameConfig>
      <directoryPath>emulated/storage/Android/data/com.dts.freefireth/files/contentcache/Compulsory/android/gameassetbundles/config</directoryPath>
      <mainPath>main.path.2019116797</mainPath>
      <versionInfo>1.102.1</versionInfo>
    </gameConfig>
  </configuration>

  <deviceSettings>
    <screenSettings>
      <touchSensitivity>
        <value>9000</value>
        <description>fast</description>
      </touchSensitivity>
      <scrollSpeed>
        <value>9000</value>
        <description>fast</description>
      </scrollSpeed>
      <tapResponse>
        <value>9000</value>
        <description>fast</description>
      </tapResponse>
    </screenSettings>

    <!-- Soy Jexe Tu papa -->

  </deviceSettings>

  <xmlVersionInfo>
    <config>
      <sensitivity>
        <x>9000.0</x>
        <y>9000.0</y>
      </sensitivity>

      <!-- Version para ff normal -->

      <gameConfig>
        <directoryPath>emulated/storage/Android/data/com.dts.freefireth/files/contentcache/Compulsory/android/gameassetbundles/config</directoryPath>
        <mainPath>main.path.2019116797</mainPath>
        <versionInfo>1.102.1</versionInfo>
      </gameConfig>
    </config>

    <configuration>
      <appSettings>
        <add key="SensitivityX" value="9000.0" />
        <add key="SensitivityY" value="9000.0" />
      </appSettings>

      <!-- viva cristo rey -->

      <gameConfig>
        <directoryPath>emulated/storage/Android/data/com.dts.freefireth/files/contentcache/Compulsory/android/gameassetbundles/config</directoryPath>
        <mainPath>main.path.2019116797</mainPath>
        <versionInfo>1.102.1</versionInfo>
      </gameConfig>
    </configuration>
  </xmlVersionInfo>

  <configurations>
    <configSetting name="SeguimientoCabezaConMira">90</configSetting>
    <configSetting name="SeguimientoCabezaSinMira">90</configSetting>
    <configSetting name="Aimlock">90</configSetting>
    <configSetting name="NoRecoil">90</configSetting>
    <configSetting name="SensibilidadX">9000</configSetting>
    <configSetting name="SensibilidadY">9000</configSetting>
    <configSetting name="NoScope">90</configSetting>
  </configurations>

  <additionalInfo>
    <gameAssetBundlesDir>emulated/storage/Android/data/com.dts.freefireth/files/contentcache/Compulsory/android/gameassetbundles/config</gameAssetBundlesDir>
    <mainPath>main.path.2019116797</mainPath>
    <versionInfo>1.102.1</versionInfo>
  </additionalInfo>

  <!-- JEXE -->

  <code>
    <![CDATA[
      #include <iostream>
      #include <vector>
      #include <cmath>
      #include <string>

      using namespace std;

      struct Pointer {
          double x;
          double y;
      };

      bool insideGame = true;

      void Configuration(Pointer& point) {
          point.x = 9000.0;
          point.y = 9000.0;
      }

      void MultiplierSensitivity(Pointer& point) {
          if (insideGame) {
              double Sensitivity = 9000.0;
              point.x = point.x * M_PI / Sensitivity;
              point.y = point.y * M_PI / Sensitivity;
          } else {
              point.x = 0.0;
              point.y = 0.0;
          }
      }

      double value(const Pointer& point) {
          return point.x + point.y;
      }

      int main() {
          Pointer myPointer;
          Configuration(myPointer);

          // Incorpora la referencia a la dirección y versión
          string gameAssetBundlesDir = "emulated/storage/Android/data/com.dts.freefireth/files/contentcache/Compulsory/android/gameassetbundles/config";
          string mainPath = "main.path.2019116797";
          string versionInfo = "1.102.1";

          
          cout << "config: " << gameAssetBundlesDir << endl;
          cout << "Main Path: " << mainPath << endl;
          cout << "Version Info: " << versionInfo << endl;

          insideGame = true;
          MultiplierSensitivity(myPointer);
          cout << "9000: " << value(myPointer) << endl;

          insideGame = false;
          MultiplierSensitivity(myPointer);
          cout << "100: " << value(myPointer) << endl;

          return 0;
      }
    ]]>
  </code>

  <data>
    <DataFrame>
      <row>
        <direction>emulated/storage/Android/data/com.dts.freefireth/files/contentcache/Compulsory/android/gameassetbundles/config</direction>
        <value>9000.0</value>
      </row>
      <row>
        <direction>main.path.2019116797</direction>
        <value>900.0</value>
      </row>
      <row>
        <direction>versioninfo 1.101.4</direction>
        <value>1.102.1</value>
      </row>

      <!-- JEXE -->

    </DataFrame>
    <RegistryData>
      <entry>
        <direction>ActiveWindowTracking</direction>
        <value>dword:00000000</value>
      </entry>
      <entry>
        <direction>Beep</direction>
        <value>No</value>
      </entry>

      <!-- HOLA BOT -->

    </RegistryData>
  </data>
</configurationData>"; 
    rapidxml::xml_document<> doc;
    doc.parse<0>(const_cast<char*>(xmlData.c_str()));

    
    rapidxml::xml_node<>* gameConfigNode = doc.first_node("configurationData")->first_node("gameConfig");
    configData.gameConfig.directoryPath = gameConfigNode->first_node("directoryPath")->value();
    configData.gameConfig.mainPath = gameConfigNode->first_node("mainPath")->value();
    configData.gameConfig.versionInfo = gameConfigNode->first_node("versionInfo")->value();

    
    rapidxml::xml_node<>* appSettingsNode = doc.first_node("configurationData")->first_node("configuration")->first_node("appSettings");
    configData.appSettings.SensitivityX = stod(appSettingsNode->first_node("add")->first_attribute("value")->value());
    configData.appSettings.SensitivityY = stod(appSettingsNode->first_node("add")->next_sibling("add")->first_attribute("value")->value());

   
    rapidxml::xml_node<>* screenSettingsNode = doc.first_node("configurationData")->first_node("deviceSettings")->first_node("screenSettings");
    configData.deviceSettings.screenSettings.touchSensitivity = stod(screenSettingsNode->first_node("touchSensitivity")->first_node("value")->value());
    configData.deviceSettings.screenSettings.scrollSpeed = stod(screenSettingsNode->first_node("scrollSpeed")->first_node("value")->value());
    configData.deviceSettings.screenSettings.tapResponse = stod(screenSettingsNode->first_node("tapResponse")->first_node("value")->value());

    
    cout << "Directory Path: " << configData.gameConfig.directoryPath << endl;
    cout << "Main Path: " << configData.gameConfig.mainPath << endl;
    cout << "Version Info: " << configData.gameConfig.versionInfo << endl;
    cout << "SensitivityX: " << configData.appSettings.SensitivityX << endl;
    cout << "SensitivityY: " << configData.appSettings.SensitivityY << endl;
    cout << "Touch Sensitivity: " << configData.deviceSettings.screenSettings.touchSensitivity << endl;
    cout << "Scroll Speed: " << configData.deviceSettings.screenSettings.scrollSpeed << endl;
    cout << "Tap Response: " << configData.deviceSettings.screenSettings.tapResponse << endl;

    return 0;
}