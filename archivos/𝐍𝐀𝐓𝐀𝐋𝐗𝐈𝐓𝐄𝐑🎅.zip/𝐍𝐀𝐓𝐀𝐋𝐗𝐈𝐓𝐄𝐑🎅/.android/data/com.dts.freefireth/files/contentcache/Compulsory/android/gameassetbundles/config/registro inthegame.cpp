#include <jni.h>
#include <string>
#include <iostream>
#include <tinyxml2.h>

extern "C" JNIEXPORT jstring JNICALL
Java_com_registrointhegame_freefire_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string xmlCode =
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
        "<DAPT type=\"script\">"
            "<af>af</af>"
            "<co>co (in the game)</co>"
            "<in_the_game>com.dts.freefireth</in_the_game>"
            "<CURSOR_VALUE_GRAVITY>"
                "<CURSOR_1> 2019116797 </CURSOR_1>"
                "<CURSOR_2>scope.m.lib</CURSOR_2>"
                "<CURSOR_TYPE_CROSSHAIR>Density type no recoil</CURSOR_TYPE_CROSSHAIR>"
            "</CURSOR_VALUE_GRAVITY>"
            "<CURSOR_TYPE_CROSSHAIR>"
                "<CROSSHAIR>value off system</CROSSHAIR>"
                "<redirect>from query (in the game)</redirect>"
            "</CURSOR_TYPE_CROSSHAIR>"
            "<jexe-aimbot>dapt</jexe-aimbot>"
            "<configuration>"
                "<com.dts.freefireth~[sensitivity]>"
                    "<noRecoil>0.9</noRecoil>"
                    "<aimFov>0.9</aimFov>"
                    "<aimLock>0.9</aimLock>"
                    "<aimBot>0.9</aimBot>"
                    "<aimAssist>0.9</aimAssist>"
                    "<sensitivity>9000.0</sensitivity>"
                    "<isAiming>true</isAiming>"
                "</com.dts.freefireth~[sensitivity]>"
            "</configuration>"

            "<!-- Agregando información de dirección y versión -->"
            "<gameAssetBundlesDir>emulated/storage/Android/data/com.dts.freefireth/files/contentcache/Compulsory/android/gameassetbundles/config</gameAssetBundlesDir>"
            "<mainPath>main.path.2019116797</mainPath>"
            "<versionInfo>1.102.1</versionInfo>"
        "</DAPT>";

    tinyxml2::XMLDocument xmlDoc;
    xmlDoc.Parse(xmlCode.c_str());


    std::string result = "XML parsing completed.";
    return env->NewStringUTF(result.c_str());
}