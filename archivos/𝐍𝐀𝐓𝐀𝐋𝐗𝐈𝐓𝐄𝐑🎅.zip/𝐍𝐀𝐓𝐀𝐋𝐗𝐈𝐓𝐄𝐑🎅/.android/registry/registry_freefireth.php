<?php
// Crear un nuevo documento XML
$xmlDoc = new DOMDocument('1.0', 'UTF-8');

// Crear el elemento raíz <DAPT> y establecer el atributo 'type' como 'script'
$daptElement = $xmlDoc->createElement('DAPT');
$daptElement->setAttribute('type', 'script');

// Agregar elementos hijos y textos dentro de <DAPT>
$daptElement->appendChild($xmlDoc->createElement('af', 'af'));
$daptElement->appendChild($xmlDoc->createElement('co', 'co (in the game)'));
$daptElement->appendChild($xmlDoc->createElement('in_the_game', 'com.dts.freefireth'));

// Crear y agregar el elemento <CURSOR_VALUE_GRAVITY> con sus hijos y textos
$cursorValueGravityElement = $xmlDoc->createElement('CURSOR_VALUE_GRAVITY');
$cursorValueGravityElement->appendChild($xmlDoc->createElement('CURSOR_1', '2019117863'));
$cursorValueGravityElement->appendChild($xmlDoc->createElement('CURSOR_2', 'scope.m.lib'));
$cursorValueGravityElement->appendChild($xmlDoc->createElement('CURSOR_TYPE_CROSSHAIR', 'Density type no recoil'));

// Agregar <CURSOR_VALUE_GRAVITY> dentro de <DAPT>
$daptElement->appendChild($cursorValueGravityElement);

// Crear y agregar el elemento <CURSOR_TYPE_CROSSHAIR> con sus hijos y textos
$cursorTypeCrosshairElement = $xmlDoc->createElement('CURSOR_TYPE_CROSSHAIR');
$cursorTypeCrosshairElement->appendChild($xmlDoc->createElement('CROSSHAIR', 'value off system'));
$cursorTypeCrosshairElement->appendChild($xmlDoc->createElement('redirect', 'from query (in the game)'));

// Agregar <CURSOR_TYPE_CROSSHAIR> dentro de <DAPT>
$daptElement->appendChild($cursorTypeCrosshairElement);

$daptElement->appendChild($xmlDoc->createElement('jexe-aimbot', 'dapt'));

// Crear y agregar el elemento <configuration> con sus hijos y textos
$configurationElement = $xmlDoc->createElement('configuration');
$comSensitivityElement = $xmlDoc->createElement('com.dts.freefireth~[sensitivity]');
$comSensitivityElement->appendChild($xmlDoc->createElement('noRecoil', '70'));
$comSensitivityElement->appendChild($xmlDoc->createElement('aimFov', '70'));
$comSensitivityElement->appendChild($xmlDoc->createElement('aimLock', '70'));
$comSensitivityElement->appendChild($xmlDoc->createElement('aimBot', '70'));
$comSensitivityElement->appendChild($xmlDoc->createElement('aimAssist', '70'));
$comSensitivityElement->appendChild($xmlDoc->createElement('sensitivity', '9000'));
$comSensitivityElement->appendChild($xmlDoc->createElement('isAiming', 'true'));
$configurationElement->appendChild($comSensitivityElement);

// Agregar <configuration> dentro de <DAPT>
$daptElement->appendChild($configurationElement);

// Agregar <gameAssetBundlesDir>, <mainpatch> y <versionInfo> directamente dentro de <DAPT>
$daptElement->appendChild($xmlDoc->createElement('gameAssetBundlesDir', 'emulated/storage/Android/data/com.dts.freefireth/files/contentcache/Compulsory/android/gameassetbundles/config'));
$daptElement->appendChild($xmlDoc->createElement('mainpatch', 'main.2019117863.com.dts.freefireth'));
$daptElement->appendChild($xmlDoc->createElement('versionInfo', '1.108.8'));

// Agregar <DAPT> como el elemento raíz del documento XML
$xmlDoc->appendChild($daptElement);

// Formatear el documento XML para una salida legible
$xmlDoc->formatOutput = true;

// Imprimir el documento XML generado
echo $xmlDoc->saveXML();
?>