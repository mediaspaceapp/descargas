#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>

// Estructura de configuración
struct Configuration {
    float noRecoil;
    float aimFov;
    float aimLock;
    float aimBot;
    float aimAssist;
    int sensitivity;
    bool isAiming;
};

// Configuración inicial
Configuration configuration = {0.60, 0.60, 0.60, 0.60, 0.60, 90000, false};

// Función para alternar características
void toggleFeature(const std::string& featureFreeFire, bool isEnabled) {
    if (featureFreeFire == "isAiming") {
        configuration.isAiming = isEnabled;
    } else if (featureFreeFire == "aimBot") {
        configuration.aimBot = isEnabled && configuration.isAiming ? 1.0 : 0.0;
    }
    // Añadir lógica para más características si es necesario
}

// Función para unir elementos de un vector con un separador
std::string join(const std::vector<std::string>& vec, const std::string& delimiter) {
    std::ostringstream result;
    for (size_t i = 0; i < vec.size(); ++i) {
        result << vec[i];
        if (i != vec.size() - 1) {
            result << delimiter;
        }
    }
    return result.str();
}

int main() {
    // Alternar las características de ejemplo
    toggleFeature("aimBot", true);
    toggleFeature("aimFov", false);

    // Crear la estructura del archivo XML
    std::ostringstream configXML;
    configXML << "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
    configXML << "<DAPT type=\"script\">\n";
    configXML << "    <!-- Other XML content -->\n";
    configXML << "    <configuration>\n";
    configXML << "        <com.dts.freefireth~[sensitivity]>\n";

    // Crear las líneas de configuración
    std::vector<std::string> configLines;
    configLines.push_back("<noRecoil>" + std::to_string(configuration.noRecoil) + "</noRecoil>");
    configLines.push_back("<aimFov>" + std::to_string(configuration.aimFov) + "</aimFov>");
    configLines.push_back("<aimLock>" + std::to_string(configuration.aimLock) + "</aimLock>");
    configLines.push_back("<aimBot>" + std::to_string(configuration.aimBot) + "</aimBot>");
    configLines.push_back("<aimAssist>" + std::to_string(configuration.aimAssist) + "</aimAssist>");
    configLines.push_back("<sensitivity>" + std::to_string(configuration.sensitivity) + "</sensitivity>");

    // Unir las líneas y añadirlas al XML
    configXML << "            " << join(configLines, "\n            ") << "\n";
    configXML << "        </com.dts.freefireth~[sensitivity]>\n";
    configXML << "    </configuration>\n";
    configXML << "</DAPT>\n";

    // Guardar el archivo de configuración
    std::ofstream configFile("config.xml");
    configFile << configXML.str();
    configFile.close();

    std::cout << "Configuration saved successfully in config.xml" << std::endl;

    return 0;
}